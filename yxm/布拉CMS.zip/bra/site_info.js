
const site_info = {
    //配置信息
    sitio_web: 'http://yxm.jxgxnxs.cn/', // 访问的地址 http://www.bra.ac/
    site_id: 1 + '', // 站点编号 一般都是1

    bra_client: 8 + '',//默认客户端 为APP 8
    bra_app_id: 3 + '',//app id 默认为移动应用  BraCms APP应用的app编号


    // #ifdef MP-WEIXIN
    bra_client: 3 + '', //小程序客户端 3
    app_id: ''  //app_id 就是小程序的官方的 app_id 类似 wx********
    // #endif

};
export default site_info;